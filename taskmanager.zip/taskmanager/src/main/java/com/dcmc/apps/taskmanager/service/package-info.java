/**
 * Service layer.
 */
package com.dcmc.apps.taskmanager.service;
