/**
 * Domain objects.
 */
package com.dcmc.apps.taskmanager.domain;
