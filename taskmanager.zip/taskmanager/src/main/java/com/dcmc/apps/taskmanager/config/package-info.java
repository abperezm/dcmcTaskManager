/**
 * Application configuration.
 */
package com.dcmc.apps.taskmanager.config;
