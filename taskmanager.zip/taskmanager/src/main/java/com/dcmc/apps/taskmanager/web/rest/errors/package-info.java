/**
 * Rest layer error handling.
 */
package com.dcmc.apps.taskmanager.web.rest.errors;
