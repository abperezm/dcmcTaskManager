package com.dcmc.apps.taskmanager.domain.enumeration;

/**
 * The WorkGroupRole enumeration.
 */
public enum WorkGroupRole {
    OWNER,
    MODERADOR,
    MIEMBRO,
}
