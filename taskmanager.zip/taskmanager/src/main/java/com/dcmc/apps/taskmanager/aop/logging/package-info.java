/**
 * Logging aspect.
 */
package com.dcmc.apps.taskmanager.aop.logging;
