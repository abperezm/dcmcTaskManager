package com.dcmc.apps.taskmanager.domain.enumeration;

/**
 * The TaskPriority enumeration.
 */
public enum TaskPriority {
    LOW,
    NORMAL,
    HIGH,
}
